package motordriver

import (
	helper "EtherCAT/helper"
	logger "EtherCAT/logger"
	"EtherCAT/motordriver/statusnotifier"
	settings "EtherCAT/settings"
	"errors"
	"fmt"
	"math"
	"time"
)

func reverseDir(masterDevice MasterDevice) error {
	logger.Trace("Reverse direction activated for driver", masterDevice.Name)
	operation, err := GetEtherCATOperation("reverse", masterDevice.Device.AddressConfigName)
	if err != nil {
		return err
	}
	for _, step := range operation.Steps {
		_ = SDODownload(masterDevice.Master, masterDevice.Position, step)
	}
	return nil
}

func nonReverseDir(masterDevice MasterDevice) error {
	logger.Trace("Non reverse direction activated for driver", masterDevice.Name)
	operation, err := GetEtherCATOperation("nonreverse", masterDevice.Device.AddressConfigName)
	if err != nil {
		return err
	}
	for _, step := range operation.Steps {
		_ = SDODownload(masterDevice.Master, masterDevice.Position, step)
	}
	return nil
}

// ManualJog runs the drive in Profile Velocity mode via PDO.
// rpm value is written directly to 0x60FF via pdoCmdVelocity atomic.
func ManualJog(masterDevice MasterDevice, direction int) error {

	driverStatus := getCurrentDriverStatus(masterDevice.Device.Name)
	if driverStatus.potNotExceeded {
		logger.Error("pot/not exceeded, exiting from jog")
		return errors.New("pot/not exceeded, exiting from jog")
	}

	// Refuse to jog while drive is faulted — sending velocity to a faulted
	// drive has no effect (opEn=false) but leaves vel=600000 in the PDO
	// which confuses the state after reset. Require fault to be cleared first.
	if (pdoFbStatus.Load() & 0x0008) != 0 {
		logger.Error("ManualJog blocked — drive is faulted (stw bit3=1), reset first")
		return errors.New("drive is faulted, reset before jogging")
	}

	logger.Trace("manual jog (PDO velocity), driver:", masterDevice.Name)

	envSettings := settings.GetDriverSettings(masterDevice.Name)
	notifyDriverStatus("set_backlash", fmt.Sprintf("%f", 0.00), masterDevice)

	FastPowerOn(masterDevice)

	_, declampErr := hasDeclamped(masterDevice, envSettings)
	if declampErr != nil {
		logger.Error(declampErr)
		statusnotifier.Alarm(declampErr.Error())
		return declampErr
	}

	notifyDriverStatus("motor_running", "true", masterDevice)

	rpm := direction * int(masterDevice.Device.RPMConst*envSettings.JogFeed)

	// Safety: ensure PP jog is OFF while doing PV jog
	pdoJogActive.Store(false)
	pdoJogStep.Store(0)

	// Switch to Profile Velocity mode
	pdoCmdMode.Store(cia402ModeProfileVelocity)
	pdoEnableRequested.Store(true)

	// Clamp to int32 range
	cmd := int64(rpm)
	if cmd > math.MaxInt32 {
		cmd = math.MaxInt32
	}
	if cmd < math.MinInt32 {
		cmd = math.MinInt32
	}
	pdoCmdVelocity.Store(int32(cmd))

	// Seed target position (harmless; helps if switching back to PP)
	pdoCmdTarget.Store(pdoFbActual.Load())

	logger.Info("ManualJog PV started. rpm=", rpm, " 60FF=", int32(cmd))
	return nil
}

// StopJog stops PV jog immediately via PDO.
// Only drops enable if the drive is actively jogging (PV mode).
// Dropping enable on an idle PP drive triggers ESM protection (FF50).
func StopJog(masterDevice MasterDevice) error {

	logger.Trace("stop jog (PDO velocity fast-stop), driver:", masterDevice.Name)

	pdoJogActive.Store(false)
	pdoJogStep.Store(0)
	pdoCmdVelocity.Store(0)

	// Only drop enable if drive is in PV mode (actively jogging).
	// Dropping enable in PP mode triggers "ESM unauthorized request" → FF50
	// because the drive interprets cwShutdown as invalid from target-reached state.
	if int8(pdoFbMode.Load()) == cia402ModeProfileVelocity {
		pdoEnableRequested.Store(false)
		go func() {
			time.Sleep(120 * time.Millisecond)
			pdoCmdTarget.Store(pdoFbActual.Load())
			pdoEnableRequested.Store(true)
		}()
	} else {
		// Already in PP or other mode — just ensure target is current position
		pdoCmdTarget.Store(pdoFbActual.Load())
	}

	notifyDriverStatus("motor_running", "false", masterDevice)

	envSettings := settings.GetDriverSettings(masterDevice.Name)
	_, clampErr := hasClamped(masterDevice, envSettings)
	if clampErr != nil {
		logger.Error(clampErr)
		statusnotifier.Alarm(clampErr.Error())
		return clampErr
	}

	logger.Info("StopJog PV done. 60FF=0, enable dropped briefly for fast stop.")
	return nil
}

func hasTargetReached(masterDevice MasterDevice) error {
	operation, err := GetEtherCATOperation("jog", masterDevice.Device.AddressConfigName)
	if err != nil {
		return err
	}
	driver := GetMotorDriver()
	driver.hasTargetReached(masterDevice, 0, 0, operation)
	return nil
}

func freeRotate(masterDevice MasterDevice, valueinDegree float64) error {
	logger.Trace("freeRotate to position, driver", masterDevice.Name, "degree:", valueinDegree)
	err := doRotate(masterDevice, valueinDegree)
	if err != nil {
		return err
	}
	doneDriverAction()
	logger.Trace("freeRotate to position completed, driver", masterDevice.Name)
	return nil
}

// doRotate moves the drive to a relative position in PP mode via PDO.
//
// Uses a dedicated pdoNewSetPoint atomic for the New Set-Point edge trigger
// instead of repurposing pdoJogActive — cleaner and race-free.
func doRotate(masterDevice MasterDevice, valueinDegree float64) error {

	FastPowerOn(masterDevice)

	envSettings := settings.GetDriverSettings(masterDevice.Name)
	_, declampErr := hasDeclamped(masterDevice, envSettings)
	if declampErr != nil {
		logger.Error(declampErr)
		statusnotifier.Alarm(declampErr.Error())
		return declampErr
	}

	notifyDriverStatus("motor_running", "true", masterDevice)

	deltaPulses64 := getPulsesFromDegree(masterDevice, helper.RoundFloatTo3(valueinDegree))
	if deltaPulses64 == 0 {
		notifyDriverStatus("motor_running", "false", masterDevice)
		_, clampErr := hasClamped(masterDevice, envSettings)
		return clampErr
	}

	currentActual := pdoFbActual.Load()

	delta := deltaPulses64
	if delta > math.MaxInt32 {
		delta = math.MaxInt32
	}
	if delta < math.MinInt32 {
		delta = math.MinInt32
	}

	target := int32(int64(currentActual) + delta)

	pdoCmdVelocity.Store(0)
	pdoJogActive.Store(false)
	pdoJogStep.Store(0)

	// Switch to PP mode and set target.
	pdoCmdMode.Store(cia402ModeProfilePosition)
	pdoCmdTarget.Store(target)
	pdoEnableRequested.Store(true)

	// Wait for drive to confirm mode switch to PP before sending new set-point.
	// If coming from PV mode (mode=3), the drive needs at least one full cycle
	// in PP mode before it will accept a new set-point. Sending pdoNewSetPoint
	// in the same cycle as the mode switch causes the drive to ignore it — bit10
	// never clears and the drive never moves.
	const (
		timeout  = 5 * time.Second
		poll     = 2 * time.Millisecond
		modeWait = 200 * time.Millisecond // max wait for mode switch confirmation
	)
	modeStart := time.Now()
	for time.Since(modeStart) < modeWait {
		if int8(pdoFbMode.Load()) == cia402ModeProfilePosition {
			break
		}
		time.Sleep(poll)
	}
	if int8(pdoFbMode.Load()) != cia402ModeProfilePosition {
		logger.Info("Warning: drive did not confirm PP mode within 200ms, proceeding anyway")
	}

	// Trigger New Set-Point handshake.
	// The cyclic holds bit4 until the drive acknowledges with stw bit12=1,
	// then clears bit4. Drive then drops bit10 and begins moving.
	pdoNewSetPoint.Store(true)

	logger.Info("PDO PP move issued. deg=", helper.RoundFloatTo3(valueinDegree), " target=", target)

	// PHASE 1: Wait for handshake to complete — pdoNewSetPoint cleared by cyclic
	// once bit12 (Set-Point Acknowledge) is seen. This guarantees the drive has
	// accepted the new target before we start watching for motion.
	ackStart := time.Now()
	for time.Since(ackStart) < 2*time.Second {
		if !pdoNewSetPoint.Load() {
			break
		}
		time.Sleep(poll)
	}
	if pdoNewSetPoint.Load() {
		// Handshake timed out — drive never set bit12. Clear the flag to avoid
		// leaving bit4 asserted indefinitely, but log the failure.
		pdoNewSetPoint.Store(false)
		logger.Info("Warning: drive did not acknowledge new set-point (bit12 timeout) — move may not execute")
	}
// PHASE 2: Wait for previous target-reached bit to clear.
// Some drives keep bit10 high for a short time after a move,
// so ensure it drops before waiting for the next motion completion.

// PHASE 2: Wait for bit10 to SET (target reached).
start := time.Now()
for time.Since(start) < timeout {

    if pdoStopRequest.Load() {
        return errors.New("move aborted: stop request active")
    }

    if (pdoFbStatus.Load() & (1 << 10)) != 0 {
        break
    }

    time.Sleep(poll)
}

if time.Since(start) >= timeout {
    return fmt.Errorf("timeout waiting for target reached (bit10)")
}

	logger.Info("Target reached (bit10) for driver:", masterDevice.Name)

	notifyDriverStatus("motor_running", "false", masterDevice)

	_, clampErr := hasClamped(masterDevice, envSettings)
	if clampErr != nil {
		logger.Error(clampErr)
		statusnotifier.Alarm(clampErr.Error())
		return clampErr
	}

	return nil
}